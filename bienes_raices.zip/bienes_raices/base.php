<?php 
    require 'includes/funciones.php';
    incluirTemplate('header');
?>

    <main class="contenedor seccion">
        <h1>Titulo Página</h1>
    </main>

<?php 
    incluirTemplate('footer');
?>